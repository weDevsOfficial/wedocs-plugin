<div class="wrap">
    <div id="wedocs-app"></div>
</div>
